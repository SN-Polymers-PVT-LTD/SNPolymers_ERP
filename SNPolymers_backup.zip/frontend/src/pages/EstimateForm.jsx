import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../components/AuthContext';
import { Button, Input, TextArea, Select, Modal } from '../components/ui';
import authApi from '../api/authApi';
import { useQueryClient } from '@tanstack/react-query';

const ESTIMATE_STATUS = {
  DRAFT: 'Draft',
  ZO_REVISION_REQUESTED: 'ZO Revision Requested',
  HO_REVISION_REQUESTED: 'HO Revision Requested',
  ESTIMATE_REOPENED: 'Estimate Reopened'
};

const formatINR = (value) => {
  const num = Number(value) || 0;
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 2
  }).format(num);
};

const EstimateForm = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const isEditMode = !!id;
  const queryClient = useQueryClient();

  // Header State
  const [workOrders, setWorkOrders] = useState([]);
  const [selectedWorkOrder, setSelectedWorkOrder] = useState('');
  const [estimateNo, setEstimateNo] = useState('');
  const [zonalOfficeNo, setZonalOfficeNo] = useState('N/A');
  const [jeRemarks, setJeRemarks] = useState('');
  
  // Project Info Metadata
  const [projectMeta, setProjectMeta] = useState({
    state: '',
    district: '',
    zone: '',
    department: '',
    siteDetails: '',
    workOrderValue: 0
  });

  // Items State
  const [items, setItems] = useState([]);
  const [purchaseOptions, setPurchaseOptions] = useState([]);
  const [mainHeads, setMainHeads] = useState(['Labour', 'Materials', 'Transport', 'Miscellaneous']);
  
  // Cascading dropdown caches
  const [subHeadsCache, setSubHeadsCache] = useState({}); // mainHead -> [subHeads]
  const [materialsCache, setMaterialsCache] = useState({}); // "mainHead|||subHead" -> [materials]

  // Status & Timing States
  const [estimateStatus, setEstimateStatus] = useState(ESTIMATE_STATUS.DRAFT);
  const [deadline, setDeadline] = useState(null);
  const [timeRemaining, setTimeRemaining] = useState('');
  const [isExpired, setIsExpired] = useState(false);
  const timerRef = useRef(null);

  // Pagination for Items (avoids UI freezing with 500+ rows)
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 15;
  const totalPages = Math.max(Math.ceil(items.length / itemsPerPage), 1);

  // General States
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [createdEstimateId, setCreatedEstimateId] = useState(null);
  const [showConfirmSubmit, setShowConfirmSubmit] = useState(false);

  const startCountdown = (targetDate) => {
    if (timerRef.current) clearInterval(timerRef.current);

    const updateTimer = () => {
      const now = new Date();
      const diffMs = targetDate - now;

      if (diffMs <= 0) {
        setTimeRemaining('Revision Deadline Expired');
        setIsExpired(true);
        if (timerRef.current) clearInterval(timerRef.current);
      } else {
        const hrs = Math.floor(diffMs / 3600000);
        const mins = Math.floor((diffMs % 3600000) / 60000);
        const secs = Math.floor((diffMs % 60000) / 1000);
        setTimeRemaining(`${hrs}h ${mins}m ${secs}s`);
      }
    };

    updateTimer();
    timerRef.current = setInterval(updateTimer, 1000);
  };

  const initForm = async () => {
    setError('');
    try {
      // Create promises for parallel execution
      const catalogPromise = (async () => {
        const verRes = await authApi.get('/master-data/version');
        const backendVersion = verRes.data?.version;
        const cachedVersion = localStorage.getItem('catalog_version');
        const cachedCatalogStr = localStorage.getItem('catalog_data');

        let catalog;
        if (cachedVersion && cachedCatalogStr && Number(cachedVersion) === Number(backendVersion)) {
          catalog = JSON.parse(cachedCatalogStr);
        } else {
          const catRes = await authApi.get('/master-data/catalog');
          catalog = catRes.data;
          localStorage.setItem('catalog_version', String(backendVersion));
          localStorage.setItem('catalog_data', JSON.stringify(catalog));
        }
        return catalog;
      })();

      const estimateDataPromise = isEditMode 
        ? authApi.get(`/estimates/${id}`)
        : authApi.get('/estimates/init');

      // For create mode, set workOrders as soon as data arrives, without waiting for catalog
      if (!isEditMode) {
        estimateDataPromise
          .then(initRes => {
            if (initRes.data?.success) {
              setWorkOrders(initRes.data.availableWorkOrders || []);
            }
          })
          .catch(err => setError(err.response?.data?.message || 'Failed to fetch work orders.'));
      }

      // Await catalog which is required for both modes to populate the items table dropdowns
      const catalog = await catalogPromise;

      // Build main heads list
      const mainHeadsList = catalog.categories.map(c => c.name).sort();
      setMainHeads(mainHeadsList);

      // Build direct O(1) mapping lookup maps
      const subHeadMap = {};
      const materialMap = {};
      catalog.categories.forEach(cat => {
        subHeadMap[cat.name] = (cat.subHeads || []).map(sh => sh.name).sort();
        (cat.subHeads || []).forEach(sh => {
          const key = `${cat.name}|||${sh.name}`;
          materialMap[key] = sh.materials || [];
        });
      });

      // Save lookups and purchase options in state cache
      setSubHeadsCache(subHeadMap);
      setMaterialsCache(materialMap);
      setPurchaseOptions(catalog.purchaseSources || []);

      if (isEditMode) {
        // Await the estimate data for edit mode
        const res = await estimateDataPromise;
        if (res.data?.success) {
          const { estimate, items: estItems } = res.data;
          setEstimateStatus(estimate.estimate_status);
          setSelectedWorkOrder(estimate.work_order_no);
          setEstimateNo(estimate.estimate_no);
          setZonalOfficeNo(estimate.zonal_office_no || '');
          setJeRemarks(estimate.je_remarks || '');
          
          if (estimate.projects_master) {
            setProjectMeta({
              state: estimate.projects_master.state,
              district: estimate.projects_master.district,
              zone: estimate.projects_master.zone,
              department: estimate.projects_master.department,
              siteDetails: estimate.projects_master.site_details,
              workOrderValue: estimate.projects_master.work_order_value
            });
          }

          const enrichedItems = (estItems || []).map((item) => {
            const subHeads = item.material_main_head ? (subHeadMap[item.material_main_head] || []) : [];
            const key = `${item.material_main_head}|||${item.material_sub_head}`;
            const mats = (item.material_main_head && item.material_sub_head) ? (materialMap[key] || []) : [];
            return {
              ...item,
              subHeadsList: subHeads,
              matsList: mats
            };
          });
          setItems(enrichedItems);

          if (estimate.active_revision_deadline) {
            setDeadline(new Date(estimate.active_revision_deadline));
            startCountdown(new Date(estimate.active_revision_deadline));
          }
        }
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to initialize estimate form.');
    }
  };

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    initForm();
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const handleWorkOrderChange = async (workOrderNo) => {
    setSelectedWorkOrder(workOrderNo);
    setError('');
    if (!workOrderNo) {
      setEstimateNo('');
      setProjectMeta({
        state: '',
        district: '',
        zone: '',
        department: '',
        siteDetails: '',
        workOrderValue: 0
      });
      return;
    }

    const selectedProj = workOrders.find(p => p.work_order_no === workOrderNo);
    if (selectedProj) {
      setEstimateNo(selectedProj.estimate_no);
      setProjectMeta({
        state: selectedProj.state,
        district: selectedProj.district,
        zone: selectedProj.zone,
        department: selectedProj.department,
        siteDetails: selectedProj.site_details,
        workOrderValue: selectedProj.work_order_value
      });
    }
  };

  // Helper: dynamic fetch subheads from cached state lookup
  const fetchSubHeads = async (mainHead) => {
    return subHeadsCache[mainHead] || [];
  };

  // Helper: dynamic fetch materials details from cached state lookup
  const fetchMaterials = async (mainHead, subHead) => {
    const key = `${mainHead}|||${subHead}`;
    return materialsCache[key] || [];
  };

  const handleItemChange = async (index, field, value) => {
    const globalIndex = (currentPage - 1) * itemsPerPage + index;
    const updated = [...items];
    const item = { ...updated[globalIndex], [field]: value };

    if (field === 'material_main_head') {
      item.material_sub_head = '';
      item.material_details = '';
      item.unit = '';
      item.subHeadsList = await fetchSubHeads(value);
      item.matsList = [];
    } else if (field === 'material_sub_head') {
      item.material_details = '';
      item.unit = '';
      item.matsList = await fetchMaterials(item.material_main_head, value);
    } else if (field === 'material_details') {
      const matched = item.matsList?.find(m => m.name === value);
      item.unit = matched ? matched.unit : '';
    }

    if (field === 'qty' || field === 'rate') {
      const q = field === 'qty' ? Number(value) || 0 : Number(item.qty) || 0;
      const r = field === 'rate' ? Number(value) || 0 : Number(item.rate) || 0;
      item.amount = Math.round(q * r * 100) / 100;
    }

    updated[globalIndex] = item;
    setItems(updated);
  };

  const handleAddItem = () => {
    if (isExpired) return;
    setItems([
      ...items,
      {
        item_id: '',
        material_main_head: '',
        material_sub_head: '',
        material_details: '',
        unit: '',
        qty: 0,
        rate: 0,
        amount: 0,
        rate_reference: '',
        source_of_purchase: '',
        subHeadsList: [],
        matsList: []
      }
    ]);
    // Navigate to the newly created item page
    const newTotalPages = Math.ceil((items.length + 1) / itemsPerPage);
    setCurrentPage(newTotalPages);
  };

  const handleRemoveItem = (index) => {
    if (isExpired) return;
    const globalIndex = (currentPage - 1) * itemsPerPage + index;
    const updated = items.filter((_, idx) => idx !== globalIndex);
    setItems(updated);
  };

  const handleSaveDraft = async () => {
    if (isExpired) return;
    setError('');
    setSuccess('');
    setSubmitting(true);
    try {
      let currentId = id || createdEstimateId;
      if (!currentId) {
        // Create header first if in new mode
        const headerRes = await authApi.post('/estimates', {
          work_order_no: selectedWorkOrder,
          zonal_office_no: zonalOfficeNo,
          je_remarks: jeRemarks
        });
        if (headerRes.data?.success) {
          currentId = headerRes.data.estimate.estimate_id;
          setCreatedEstimateId(currentId);
        }
      }

      // Clean up items for backend validation (remove frontend-only properties and empty UUID strings)
      const cleanedItems = items.map(item => {
        const cleaned = {
          material_main_head: item.material_main_head,
          material_sub_head: item.material_sub_head,
          material_details: item.material_details,
          unit: item.unit,
          qty: item.qty,
          rate: item.rate,
          rate_reference: item.rate_reference || null,
          source_of_purchase: (item.source_of_purchase && item.source_of_purchase !== '') ? item.source_of_purchase : null
        };
        if (item.item_id && item.item_id !== '') {
          cleaned.item_id = item.item_id;
        }
        return cleaned;
      });

      // Save line items and header details
      const saveRes = await authApi.put(`/estimates/${currentId}/items`, {
        items: cleanedItems,
        zonal_office_no: zonalOfficeNo,
        je_remarks: jeRemarks
      });
      if (saveRes.data?.success) {
        setSuccess('Estimate draft saved successfully.');
        queryClient.invalidateQueries({ queryKey: ['estimates'] });
        if (currentId) {
          queryClient.invalidateQueries({ queryKey: ['estimate', String(currentId)] });
        }
        setTimeout(() => navigate(`/estimates/${currentId}`), 1500);
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to save estimate draft.');
      // Refresh project list on 409 conflict
      if (err.response?.status === 409) {
        initForm();
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleSubmit = async () => {
    if (isExpired) return;

    const grossTotal = calculateGrossTotal();
    const woValue = projectMeta.workOrderValue || 0;
    if (grossTotal > woValue) {
      setError(`Cannot submit estimate. Total estimate cost (${formatINR(grossTotal)}) exceeds the Work Order Value (${formatINR(woValue)}).`);
      return;
    }

    setShowConfirmSubmit(true);
  };

  const executeSubmit = async () => {
    setShowConfirmSubmit(false);
    setError('');
    setSuccess('');
    setSubmitting(true);
    try {
      let currentId = id || createdEstimateId;
      if (!currentId) {
        const headerRes = await authApi.post('/estimates', {
          work_order_no: selectedWorkOrder,
          zonal_office_no: zonalOfficeNo,
          je_remarks: jeRemarks
        });
        currentId = headerRes.data.estimate.estimate_id;
        setCreatedEstimateId(currentId);
      }

      // Clean up items for backend validation
      const cleanedItems = items.map(item => {
        const cleaned = {
          material_main_head: item.material_main_head,
          material_sub_head: item.material_sub_head,
          material_details: item.material_details,
          unit: item.unit,
          qty: item.qty,
          rate: item.rate,
          rate_reference: item.rate_reference || null,
          source_of_purchase: (item.source_of_purchase && item.source_of_purchase !== '') ? item.source_of_purchase : null
        };
        if (item.item_id && item.item_id !== '') {
          cleaned.item_id = item.item_id;
        }
        return cleaned;
      });

      // 1. Save current items draft & header details
      await authApi.put(`/estimates/${currentId}/items`, {
        items: cleanedItems,
        zonal_office_no: zonalOfficeNo,
        je_remarks: jeRemarks
      });

      // 2. Submit estimate
      const submitRes = await authApi.post(`/estimates/${currentId}/submit`);
      if (submitRes.data?.success) {
        setSuccess('Estimate submitted successfully.');
        queryClient.invalidateQueries({ queryKey: ['estimates'] });
        if (currentId) {
          queryClient.invalidateQueries({ queryKey: ['estimate', String(currentId)] });
        }
        setTimeout(() => navigate(`/estimates/${currentId}`), 1500);
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to submit estimate.');
    } finally {
      setSubmitting(false);
    }
  };

  const paginatedItems = items.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const calculateGrossTotal = () => {
    return items.reduce((acc, curr) => acc + (Number(curr.amount) || 0), 0);
  };

  const isRevisionMode = estimateStatus === ESTIMATE_STATUS.ZO_REVISION_REQUESTED || estimateStatus === ESTIMATE_STATUS.HO_REVISION_REQUESTED;
  const isFormLockedByExpiry = isExpired && user?.role !== 'admin';

  return (
    <>
      <main className="flex-grow p-6 md:p-10 overflow-y-auto max-w-[96%] mx-auto w-full relative z-10">
        
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6 mb-8 pb-6 border-b border-white/5">
          <div>
            <span className="text-[10px] uppercase font-bold tracking-widest text-amber-500 font-mono">JE Console</span>
            <h1 className="text-3xl font-extrabold tracking-tight text-slate-100 mt-1">
              {isEditMode ? 'Modify Cost Estimate' : 'New Cost Estimate'}
            </h1>
            <p className="text-xs text-slate-400 font-medium mt-1.5">Compose estimate line items and select relevant materials.</p>
          </div>
          <Button
            onClick={() => navigate('/estimates')}
            variant="secondary"
          >
            Cancel & Back
          </Button>
        </div>

        {/* Overdue alert / Countdown Timer */}
        {isRevisionMode && deadline && (
          <div className={`p-4 rounded-2xl mb-6 border text-xs font-bold flex justify-between items-center ${
            isExpired ? 'bg-red-950/20 border-red-500/30 text-red-400' : 'bg-amber-950/20 border-amber-500/30 text-amber-400'
          }`}>
            <span>Revision stage: {estimateStatus}</span>
            <span className="font-mono">Time Remaining: {timeRemaining}</span>
          </div>
        )}

        {error && (
          <Modal
            isOpen={true}
            onClose={() => setError('')}
            title="Action Rejected"
            subtitle="Validation Alert"
            size="sm"
            footer={
              <Button
                variant="primary"
                onClick={() => setError('')}
                className="w-full bg-red-500 hover:bg-red-600 text-slate-950 font-bold"
              >
                Modify Estimate
              </Button>
            }
          >
            <div className="text-center py-4 space-y-4">
              <div className="mx-auto w-12 h-12 rounded-full bg-red-500/10 border border-red-500/20 flex items-center justify-center">
                <svg className="w-6 h-6 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
              </div>
              <p className="text-xs text-slate-300 px-4 leading-relaxed font-semibold">
                {error}
              </p>
            </div>
          </Modal>
        )}

        {success && (
          <Modal
            isOpen={true}
            onClose={() => setSuccess('')}
            title="Action Successful"
            subtitle="JE Console"
            size="sm"
            footer={
              <Button
                variant="amber"
                onClick={() => setSuccess('')}
                className="w-full"
              >
                Continue
              </Button>
            }
          >
            <div className="text-center py-4 space-y-4 animate-fadeIn">
              <div className="mx-auto w-12 h-12 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center">
                <svg className="w-6 h-6 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <p className="text-xs text-slate-300 px-4 leading-relaxed font-semibold">
                {success}
              </p>
            </div>
          </Modal>
        )}

        {/* Header Form */}
        <div className="glass-panel p-6 rounded-3xl mb-8 border border-white/5 space-y-6">
          <h3 className="text-xs uppercase font-extrabold tracking-widest text-slate-400 mb-4">Estimate Header</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">
                Work Order Number
              </span>
              {isEditMode ? (
                <Input
                  type="text"
                  value={selectedWorkOrder}
                  disabled
                />
              ) : (
                <Select
                  value={selectedWorkOrder}
                  onChange={(e) => handleWorkOrderChange(e.target.value)}
                  disabled={isFormLockedByExpiry || submitting}
                  required
                >
                  <option value="">Select Work Order</option>
                  {workOrders.map((p) => (
                    <option key={p.work_order_no} value={p.work_order_no} className="bg-slate-900 text-slate-100">
                      {p.work_order_no} ({p.zone})
                    </option>
                  ))}
                </Select>
              )}
            </div>

            <div>
              <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">
                Estimate Number (Auto)
              </span>
              <Input
                type="text"
                value={estimateNo}
                disabled
              />
            </div>
          </div>

          {/* Project Metadata Preview */}
          {selectedWorkOrder && (
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4 p-4 bg-white/[0.02] border border-white/5 rounded-2xl text-[11px] text-slate-400">
              <div>
                <span className="font-semibold block text-slate-500 uppercase text-[9px] tracking-wider mb-1">State / District</span>
                <span className="text-slate-200">{projectMeta.state} / {projectMeta.district}</span>
              </div>
              <div>
                <span className="font-semibold block text-slate-500 uppercase text-[9px] tracking-wider mb-1">Area Code / Department</span>
                <span className="text-slate-200">{projectMeta.zone} / {projectMeta.department}</span>
              </div>
              <div className="col-span-2">
                <span className="font-semibold block text-slate-500 uppercase text-[9px] tracking-wider mb-1">Site Details</span>
                <span className="text-slate-200 truncate block">{projectMeta.siteDetails}</span>
              </div>
              <div>
                <span className="font-semibold block text-slate-500 uppercase text-[9px] tracking-wider mb-1">Work Order Value</span>
                <span className="text-slate-200 font-mono font-bold">{new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(projectMeta.workOrderValue)}</span>
              </div>
            </div>
          )}

          <div>
            <TextArea
              label="JE Remarks / Special Instructions"
              rows={2}
              value={jeRemarks}
              onChange={(e) => setJeRemarks(e.target.value)}
              placeholder="Enter context, rate assumptions, or instructions..."
              disabled={isFormLockedByExpiry || submitting}
            />
          </div>
        </div>

        {/* Cost Estimates Items Editor */}
        <div className="glass-panel rounded-3xl border border-white/5 overflow-hidden">
          <div className="flex justify-between items-center p-6 bg-white/[0.01] border-b border-white/5">
            <h3 className="text-xs uppercase font-extrabold tracking-widest text-slate-400">Estimate Items</h3>
            <Button
              type="button"
              onClick={handleAddItem}
              variant="amber"
              size="sm"
              disabled={isFormLockedByExpiry || submitting}
            >
              Add Item
            </Button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse min-w-[1200px]">
              <thead>
                <tr className="border-b border-white/5 bg-white/[0.02] text-[9px] uppercase tracking-widest text-slate-400 font-mono">
                  <th className="py-4 px-6 w-48">Main Category</th>
                  <th className="py-4 px-6 w-48">Sub Head</th>
                  <th className="py-4 px-6">Material Details</th>
                  <th className="py-4 px-6 w-24">Unit</th>
                  <th className="py-4 px-6 w-24">Qty</th>
                  <th className="py-4 px-6 w-28">Rate (₹)</th>
                  <th className="py-4 px-6 w-36">Rate Reference</th>
                  <th className="py-4 px-6 w-40">Source of Purchase</th>
                  <th className="py-4 px-6 w-32">Amount</th>
                  <th className="py-4 px-6 w-16 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-xs text-slate-300">
                {paginatedItems.map((item, idx) => {
                  const globalIdx = (currentPage - 1) * itemsPerPage + idx;
                  const isLocked = user?.role !== 'admin' && (
                    (isRevisionMode && (
                      (estimateStatus === ESTIMATE_STATUS.ZO_REVISION_REQUESTED && item.zo_office_approve === 'Approve') ||
                      (estimateStatus === ESTIMATE_STATUS.HO_REVISION_REQUESTED && item.ho_office_approve === 'Approve')
                    )) ||
                    (estimateStatus === ESTIMATE_STATUS.ESTIMATE_REOPENED && !!item.item_id)
                  );

                  const isRejected = isRevisionMode && (
                    (estimateStatus === ESTIMATE_STATUS.ZO_REVISION_REQUESTED && item.zo_office_approve === 'Not Approve') ||
                    (estimateStatus === ESTIMATE_STATUS.HO_REVISION_REQUESTED && item.ho_office_approve === 'Not Approve')
                  );

                  return (
                    <tr key={globalIdx} className={`hover:bg-white/[0.01] transition-colors duration-200 ${
                      isRejected ? 'border-l-4 border-l-amber-500 bg-amber-500/[0.01]' : ''
                    } ${isLocked ? 'opacity-60 bg-white/[0.01] pointer-events-none' : ''}`}>
                      <td className="py-3 px-4">
                        <select
                           value={item.material_main_head}
                           onChange={(e) => handleItemChange(idx, 'material_main_head', e.target.value)}
                           className="w-full glass-input p-2 rounded-lg text-xs"
                           disabled={isFormLockedByExpiry || submitting || isLocked}
                        >
                          <option value="">Select Main Head</option>
                          {mainHeads.map(h => <option key={h} value={h}>{h}</option>)}
                        </select>
                      </td>
                      <td className="py-3 px-4">
                        <select
                           value={item.material_sub_head}
                           onChange={(e) => handleItemChange(idx, 'material_sub_head', e.target.value)}
                           className="w-full glass-input p-2 rounded-lg text-xs"
                           disabled={isFormLockedByExpiry || submitting || isLocked || !item.material_main_head}
                        >
                          <option value="">Select Sub Head</option>
                          {item.subHeadsList?.map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                      </td>
                      <td className="py-3 px-4">
                        <select
                           value={item.material_details}
                           onChange={(e) => handleItemChange(idx, 'material_details', e.target.value)}
                           className="w-full glass-input p-2 rounded-lg text-xs"
                           disabled={isFormLockedByExpiry || submitting || isLocked || !item.material_sub_head}
                        >
                          <option value="">Select Details</option>
                          {item.matsList?.map((m, mIdx) => (
                            <option key={`${m.id || m.name}-${mIdx}`} value={m.name}>
                              {m.name}
                            </option>
                          ))}
                        </select>
                      </td>
                      <td className="py-3 px-4">
                        <input
                          type="text"
                          value={item.unit}
                          readOnly
                          className="w-full glass-input p-2 rounded-lg text-xs text-center font-bold text-slate-400 cursor-not-allowed"
                        />
                      </td>
                      <td className="py-3 px-4">
                        <input
                          type="number"
                          min="0.01"
                          step="any"
                          value={item.qty || ''}
                          onChange={(e) => handleItemChange(idx, 'qty', e.target.value)}
                          className="w-full glass-input p-2 rounded-lg text-xs font-semibold text-center"
                          disabled={isFormLockedByExpiry || submitting || isLocked}
                        />
                      </td>
                      <td className="py-3 px-4">
                        <input
                          type="number"
                          min="0.01"
                          step="any"
                          value={item.rate || ''}
                          onChange={(e) => handleItemChange(idx, 'rate', e.target.value)}
                          className="w-full glass-input p-2 rounded-lg text-xs font-semibold text-center"
                          disabled={isFormLockedByExpiry || submitting || isLocked}
                        />
                      </td>
                      <td className="py-3 px-4">
                        <input
                          type="text"
                          placeholder="e.g. CSR 2026"
                          value={item.rate_reference || ''}
                          onChange={(e) => handleItemChange(idx, 'rate_reference', e.target.value)}
                          className="w-full glass-input p-2 rounded-lg text-xs"
                          disabled={isFormLockedByExpiry || submitting || isLocked}
                        />
                      </td>
                      <td className="py-3 px-4">
                        <select
                          value={item.source_of_purchase || ''}
                          onChange={(e) => handleItemChange(idx, 'source_of_purchase', e.target.value)}
                          className="w-full glass-input p-2 rounded-lg text-xs"
                          disabled={isFormLockedByExpiry || submitting || isLocked || user?.role === 'je' || user?.role === 'staff'}
                        >
                          <option value="">Select Source</option>
                          {purchaseOptions.map(o => <option key={o.id} value={o.id}>{o.name}</option>)}
                        </select>
                      </td>
                      <td className="py-3 px-4 font-mono font-bold text-slate-200">
                        {formatINR(item.amount)}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <button
                          type="button"
                          onClick={() => handleRemoveItem(idx)}
                          className="text-red-400 hover:text-red-300 p-1.5 hover:bg-white/5 rounded-lg transition"
                          disabled={isFormLockedByExpiry || submitting || isLocked}
                          title="Remove item"
                        >
                          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                          </svg>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Table Summary Footer */}
          <div className="flex justify-between items-center p-6 bg-white/[0.01] border-t border-white/5 text-xs">
            <span className="text-slate-400 font-bold uppercase tracking-widest font-mono">Gross Estimate Total</span>
            <span className="font-mono text-xl font-extrabold text-amber-500">{formatINR(calculateGrossTotal())}</span>
          </div>
        </div>

        {/* Pagination Controls */}
        {totalPages > 1 && (
          <div className="mt-4 flex justify-between items-center text-xs text-slate-400">
            <span>Showing items {(currentPage - 1) * itemsPerPage + 1} - {Math.min(currentPage * itemsPerPage, items.length)} of {items.length}</span>
            <div className="flex gap-2">
              <Button
                type="button"
                onClick={() => setCurrentPage(p => Math.max(p - 1, 1))}
                disabled={currentPage === 1}
                size="sm"
                variant="secondary"
              >
                Prev
              </Button>
              <Button
                type="button"
                onClick={() => setCurrentPage(p => Math.min(p + 1, totalPages))}
                disabled={currentPage === totalPages}
                size="sm"
                variant="secondary"
              >
                Next
              </Button>
            </div>
          </div>
        )}

        {/* Submit Actions */}
        <div className="mt-8 flex justify-end gap-4">
          <Button
            type="button"
            onClick={handleSaveDraft}
            variant="secondary"
            disabled={isFormLockedByExpiry || submitting || items.length === 0}
          >
            Save as Draft
          </Button>
          <Button
            type="button"
            onClick={handleSubmit}
            variant="primary"
            disabled={isFormLockedByExpiry || submitting || items.length === 0}
          >
            {submitting ? 'Submitting...' : 'Submit Estimate'}
          </Button>
        </div>
      </main>

      <Modal
        isOpen={showConfirmSubmit}
        onClose={() => setShowConfirmSubmit(false)}
        title="Submit Cost Estimate?"
        subtitle="Work Order Actions"
        size="sm"
      >
        <div className="flex flex-col items-center text-center">
          {/* Submit Icon */}
          <div className="w-16 h-16 rounded-full bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 mb-6 shadow-inner animate-pulse">
            <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>

          <p className="text-xs text-slate-400 font-medium mb-6 leading-relaxed">
            Submit this cost estimate for review? You will not be able to edit items unless a revision is requested.
          </p>

          <div className="flex gap-4 w-full">
            <button
              type="button"
              onClick={() => setShowConfirmSubmit(false)}
              className="flex-1 bg-white/5 hover:bg-white/10 text-slate-200 font-bold py-3 px-6 rounded-2xl border border-white/5 transition duration-300"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={executeSubmit}
              className="flex-1 bg-gradient-to-tr from-amber-500 to-amber-400 hover:from-amber-600 hover:to-amber-500 text-slate-950 font-bold py-3 px-6 rounded-2xl transition duration-300 shadow-[0_0_20px_rgba(245,158,11,0.25)]"
            >
              Confirm
            </button>
          </div>
        </div>
      </Modal>
    </>
  );
};

export default EstimateForm;
